#ifndef QUEUE_H_
#define QUEUE_H_

class Queuer {
public:
    Queuer();
private:
    Queuer *next;
    friend class Queue;
};

class Queue {
public:
    Queue();
    Queuer &push(Queuer&);      // at the beginning
    Queuer &append(Queuer&);    // at the end
    Queuer *pop();
    Queuer *getNext(Queuer*);   // input 0 to get first, return 0 for last
private:
    Queuer *last;
};

#endif /* QUEUE_H_ */
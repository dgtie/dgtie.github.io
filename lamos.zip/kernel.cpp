#include "lamos.h"

void _swi_set(void);
int *_get_sp(void);
void _syscall(void);

namespace
{
    
class KQueue : Queue {
public:
	KQueue(KQueue *n) { next = n; }
	void append(Service &s) {
		if (popping == this) next->push(s);
		else Queue::append(s);
		if (next) _swi_set();   // no need to raise interrupt for kernel queue
	}
	Service *pop(void) {
		Service *s;
		popping = this; s = (Service*)Queue::pop(); popping = 0;
		if (!s) if (next) return next->pop();
		return s;
	}
private:
	KQueue *next;
	static KQueue *popping;
} kQueue(0), iQueue0(&kQueue);

KQueue *KQueue::popping;

} // anonymous

Service::Service(SERVICE s) { service = s; }

void Service::append(void) { kQueue.append(*this); }

void Service::append(SERVICE s) { service = s; kQueue.append(*this); }

void Service::append(int) { iQueue0.append(*this); }

void Service::set(SERVICE s) { service = s; }

int *_kernel(void) {
	Service *s;
    _syscall();
    while ((s = iQueue0.pop())) (*s->service)(*s);
    return _get_sp();
}

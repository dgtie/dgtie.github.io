#include "lamos.h"

void _swi_set(void);
int *_setup_stack(int *stack);

class MainThread : public Thread {
public:
    MainThread(void) : thread(this) { queue.append(*this); }
    int *save_sp(int *i) { thread->sp = i; return sp;}
    int *get_sp(void) { return thread->sp; }
    int get_parameter(void) { return thread->parameter; }
    void set_parameter(int i) { thread->parameter = i; }
    void set_wait(WAIT w) {
        thread->wait = w;
        while (thread->wait);
    }
    int set_syscall(int i, SYSCALL s) {
        thread->parameter = i;
        syscall = s;
        _swi_set();
        return thread->parameter;
    }
    int add_thread(int i) {
        int *stack = (int*)i;
        Thread *t = (Thread*)stack[0];
        t->sp = _setup_stack(stack);
        queue.append(*t);
        return i;
    }
    bool nextThread(void) {
        thread = (Thread*)queue.getNext(thread);
        if (!thread) thread = this;
        return thread->wait;
    }
    Thread *wake(Thread *t) {
        if ((t = (Thread*)queue.getNext(t)))
            if (t->wait)
                if (!(*t->wait)(t->parameter))
                    t->wait = 0;
        return t;
    }
    void exec_syscall(void) {
        if (syscall) {
            thread->parameter = (*syscall)(thread->parameter);
            syscall = 0;
        }
    }
private:
    Queue queue;
    Thread *thread;
    SYSCALL syscall;
};

namespace
{
    
MainThread mainThread;

int add_thread(int i) { return mainThread.add_thread(i); }

void nextThread(Service &s) {
    if (mainThread.nextThread()) s.append();
}

} // anonymous

extern "C" int *_save_sp(int *i) { return mainThread.save_sp(i); }

int *_get_sp(void) { return mainThread.get_sp(); }

void _thread(Service &s) {
    static Thread *t;
    s.append((t = mainThread.wake(t)) ? _thread : nextThread);
}

void _syscall(void) { mainThread.exec_syscall(); }

Thread::Thread(int* stack, int size, THREAD pc) : Thread() {
    stack[0] = (int)this;
    stack[1] = size;
    stack[2] = (int)pc;
    user::syscall((int)stack, add_thread);
}

Thread::Thread(void) : wait(0) {}

namespace user
{
    
int wait(int i, WAIT w) {
    mainThread.set_parameter(i);
    mainThread.set_wait(w);
    return mainThread.get_parameter();
}
    
int syscall(int i, SYSCALL s) { return mainThread.set_syscall(i, s); }

void wait(int t) { wait(t, [](int &i){ return (bool)--i; }); }

}

#include <stm32f10x.h>
#include "lamos.h"

extern Service _systick;
int *_kernel(void);
extern "C" int *_save_sp(int*);

void _swi_set(void) { SCB->ICSR |=  SCB_ICSR_PENDSVSET_Msk; }

void _kernel_init(void) {
	SysTick_Config(72000);
	NVIC_SetPriorityGrouping(6U);	//NVIC_PriorityGroup_1
	// 1 bit for preemption, 3 bits for sub priority
	NVIC_SetPriority(SVCall_IRQn, 7);
	NVIC_SetPriority(SysTick_IRQn, 7);
	NVIC_SetPriority(PendSV_IRQn, 15);
}

/* https://www.adamh.cz/blog/2016/07/context-switch-on-the-arm-cortex-m0/ */
// r4 r5 r6 r7 r8 r9 r10 r11 lr
// r0 r1 r2 r3 r12 lr pc xpsr
int *_setup_stack(int *stack) {
	int size = stack[1];
	int *sp = &stack[size - 17];
	sp[8] = 0xfffffff9;		// LR
	sp[15] = stack[2];		// PC
	sp[16] = 0x01000000;	// xPSR
	return sp;
}

extern "C" void SysTick_Handler(void) { _systick.append(0); }

extern "C" int *_kernel_(void) {
	SCB->ICSR |=  SCB_ICSR_PENDSVCLR_Msk;
	return _kernel();
}

#include "queue.h"

Queuer::Queuer() : next(0) {}

Queue::Queue() : last(0) {}

Queuer &Queue::push(Queuer &p) {
	if (!p.next) {
		if (last) p.next = last->next; else last = &p;
		last->next = &p;
	}
	return p;
}

Queuer &Queue::append(Queuer &p) {
	if (!p.next) last = &push(p);
	return p;
}

Queuer *Queue::pop() {
	if (!last) return 0;
	Queuer *p = last->next;
	last->next = p->next;
	p->next = 0;
	if (!last->next) last = 0;
	return p;
}

Queuer *Queue::getNext(Queuer *p) {
	if (p) return p == last ? 0 : p->next;
	return last ? last->next : 0;
}

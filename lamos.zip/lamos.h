#ifndef LAMOS_H_
#define LAMOS_H_

#include "queue.h"

// all ISR should be at the same priority that higher than kernel

typedef void (*SERVICE)(class Service &);
typedef unsigned (*TIMER)(void);
typedef int (*SYSCALL)(int);
typedef bool (*WAIT)(int&);         // return true to wait, false to exit
typedef void (*THREAD)(void);

class Service : public Queuer {
public:
	Service(SERVICE);
	void append(void);      // kernel queue
	void append(SERVICE);   // kernel queue
	void append(int);       // isr queue
private:
	void set(SERVICE);
	SERVICE service;
	friend int *_kernel(void);
};

class Timer : public Queuer {
public:
	Timer(unsigned, TIMER);
	static unsigned getTick(void);
private:
	unsigned count;
	TIMER task;
	friend void _nextTimer(Service&);
};

class Thread : public Queuer {
public:
    Thread(int* stack, int size, THREAD);
protected:
    Thread(void);
private:
    int *sp, parameter;
    volatile WAIT wait;
    friend class MainThread;
};

namespace user {
    void wait(int);
    int wait(int, WAIT);
    int syscall(int, SYSCALL);
}

#endif /* LAMOS_H_ */
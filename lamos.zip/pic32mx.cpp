#include <xc.h>
#include <sys/attribs.h>
#include "lamos.h"

extern Service _systick;
int *_kernel(void);
extern "C" int *_save_sp(int*);

void _swi_set(void) { IFS0SET = _IFS0_CS0IF_MASK; }

void _kernel_init(void) {
    _CP0_SET_COMPARE(24000);  // 1ms (SYSCLK = 48MHz)
    _CP0_SET_COUNT(0);
    IPC0bits.CTIP = 2;
    IPC0bits.CS0IP = 1;
    IFS0CLR = _IFS0_CS0IF_MASK | _IFS0_CTIF_MASK;
    IEC0SET = _IEC0_CS0IE_MASK | _IEC0_CTIE_MASK;
}

int *_setup_stack(int *stack) {
    int size = stack[1];
    int *sp = &stack[size - 38];
    sp[35] = 0;             // SRSCtl
    sp[36] = 0x00100003;    // Status
    sp[37] = stack[2];      // EPC
    return sp;
}

extern "C" void __ISR(_CORE_TIMER_VECTOR, ipl2AUTO) _ct_isr(void) {
    IFS0CLR = _IFS0_CTIF_MASK;
    _CP0_SET_COMPARE(_CP0_GET_COMPARE() + 24000);
    _systick.append(0);
}

extern "C" void __ISR(_CORE_SOFTWARE_0_VECTOR, ipl1AUTO) _cs0_isr(void) {
    int *sp;
    asm("move %0,$sp":"=r"(sp)::"s0","s1","s2","s3");
    sp = _save_sp(sp);
    asm("move $sp,%0"::"r"(sp):"s4","s5","s6","s7");
    IFS0CLR = _IFS0_CS0IF_MASK;
    sp = _kernel();
    asm("move $sp,%0"::"r"(sp):"fp");
}

#include "lamos.h"

void _kernel_init(void);
void _nextTimer(Service&);
void _thread(Service&);

namespace
{
    
Queuer *queue;      // to get rid of static initialization order fiasco
volatile unsigned tick;
Service timer(0);

SERVICE construct(void) {
    _kernel_init();
    return [](Service&){ tick++; timer.append(_nextTimer); };
}

} // anonymous

Service _systick(construct());

void _nextTimer(Service &s) {
	static Timer *t;
    Queue *q = (Queue*)&queue;
	if ((t = (Timer*)q->getNext(t))) {
		if (!--(t->count)) t->count = (*(t->task))();
		s.append();
	} else s.append(_thread);
}

Timer::Timer(unsigned c, TIMER t) : count(c), task(t) {
    Queue *q = (Queue*)&queue;
	q->append(*this);
}

unsigned Timer::getTick(void) { return tick; }
